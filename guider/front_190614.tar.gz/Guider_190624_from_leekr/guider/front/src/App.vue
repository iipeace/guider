<template>
  <div id='app'>


    <div class="small">
    <!--
      <line-chart
        :chart-data="chartData"
        :options="{responsive: true, maintainAspectRatio: false}">
      </line-chart>
-->
    <line-chart
      :chart-data="dataCollection"
      :options="chartOptions"
      :bind="true"
    ></line-chart>
    <socket-io></socket-io>
    </div>
  </div>
</template>

<script>
//import ReactiveBarChart from "./ReactiveBarChart.vue";
import LineChart from './LineChart.vue'
import SocketIO from './SocketIO.vue'
import { EventBus } from './event-bus';

export default {
  name: 'ChartContainer',
  components: {
      'socket-io':SocketIO, LineChart},
  data() {
    return {
      dataCollection : null,
      originalDataA: [0,0,0,0,0,0,0,0],
      originalDataB: [0,0,0,0,0,0,0,0],
      originalDataC: [0,0,0,0,0,0,0,0],
      originalDataD: [0,0,0,0,0,0,0,0],
      emitCount: 0,
      chartOptions :
      {
          scales: {
              yAxes: [{
                      display: true,
                      ticks: {
                          min:0,
                          max:100
                      }
                  }]
          },
          responsive: true,
          maintainAspectRatio: false
      }
    }
  },
  watch: {
    originalDataA: function(data) {
        this.initChart();
    }
  },
  methods: {
    initChart() {
      this.dataCollection = {
        labels: [this.lbM(-7), this.lbM(-6), this.lbM(-5), this.lbM(-4), this.lbM(-3), this.lbM(-2), this.lbM(-1), this.lbM(0)],
        datasets: [
          {
            label: "Core1",
            borderColor: "blue",
            fill:false,
            data: this.originalDataA
          },
          {
            label: "Core2",
            borderColor: "red",
            fill:false,
            data: this.originalDataB
          },
          {
            label: "Core3",
            borderColor: "purple",
            fill:false,
            data: this.originalDataC
          },
          {
            label: "Core4",
            borderColor: "black",
            fill:false,
            data: this.originalDataD
          },
        ]
      };
    },
    lbM(val){ // lbM = labelmake
      return String(this.emitCount + val -1 )
    }
  },
  created() {
    this.emitCount = 0;

  },
  mounted: function() {
    this.initChart();
    EventBus.$on("cpu_emit", cpu_emit => {
      this.emitCount = this.emitCount +1;
    });
    EventBus.$on("cpu_total", cpuTotal => {
      this.originalDataA.shift();
      this.originalDataA.push(cpuTotal[0]);
      this.originalDataB.shift();
      this.originalDataB.push(cpuTotal[1]);
      this.originalDataC.shift();
      this.originalDataC.push(cpuTotal[2]);
      this.originalDataD.shift();
      this.originalDataD.push(cpuTotal[3]);
    });
  }
}


</script>

<style lang="scss">
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}

h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}
</style>
