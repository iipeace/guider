

<script>

import { Line, mixins } from 'vue-chartjs';
import { EventBus } from './event-bus';

const { reactiveProp } = mixins

export default {
  extends: Line,
  mixins: [reactiveProp],
  props: {
    chartdata: {
      type: Object,
      default: null
    },
    options: {
      type: Object,
      default: null
    }
  },
  mounted () {
    // this.chartData is created in the mixin.
    // If you want to pass options please create a local options object
    this.renderChart(this.chartData, this.options)
  }
}
</script>

<!--

<script>

import { Line } from 'vue-chartjs';
import { EventBus } from './event-bus';

export default {
  extends: Line,
  mounted () {
    this.renderChart({
      labels: ['A', 'B', 'C', 'D', 'E', 'F'],
      datasets: [
        {
          label: 'Data One',
          backgroundColor: '#f87979',
          data: [40, 39, 10, 40, 39, 10]
        }
      ]
    }, {responsive: true, maintainAspectRatio: false})
  },
  created() {
    EventBus.$on("temp-event", tempValue => {
      console.log("event recieved : ", tempValue);
      this.labels.push(tempValue);
      this.data.push(tempValue);


    });

  }
}
</script>

-->
