<template>
  <div>
    <div>
        <input type="text" v-model="clientMsg" @keyup.enter="emitMsg"/>
        <button id="emitStart" @click="emitStart">Start</button>
        <input type="text" v-model="targetTimestamp" />
        <button id="emitStop" @click="emitStop">Stop</button>
        <button id="connectSocket" @click="connectSocket">Connect</button>
        <button id="disconnectSocket" @click="disconnectSocket">Disconnect</button>
    </div>
    <br /> Hello world
    <pre>{{ clientMsg }}</pre>
    <pre>{{ log }}</pre>
  </div>
</template>


<script>
import { EventBus } from './event-bus';

export default {
  name: 'socket-io',
    data() {
      return {
        clientMsg: "",
        log: "",
        targetTimestamp: "",
        emitCount:0

    }
  },
    sockets: {
        connect: function () {
            this.connectSocket();
        },
        server_response: function (msg) { // msg is json
            //this.appendLog(msg.data + " timestamp: " + msg.timestamp + " length : " + msg.length_pipe);
            //this.appendLog(msg.cpu_pipe);
            var emit_data = this.refine_pipe(msg.cpu_pipe);
            console.log("Emit count : ",this.emitCount);
            EventBus.$emit("cpu_emit", this.emitCount);
            EventBus.$emit("cpu_total", emit_data);
            this.emitCount = this.emitCount + 1;

        },
        request_stop_result : function (msg) {
            this.appendLog(msg);
        }
    },
    methods: {
        emitStart: function () {
            console.log("Start button Clicked!");
            var timestamp = + new Date();
            //this.$socket.emit('custom_connect', timestamp);
            this.$socket.emit('request_start', String(timestamp), { data: this.clientMsg });
        },
        emitStop: function () {
            console.log("Stop button Clicked!");
            //this.$socket.emit('custom_connect', timestamp);
            this.$socket.emit('request_stop', this.targetTimestamp);
        },
        appendLog: function (newLog) {
            this.log += newLog + "\n";
        },
        disconnectSocket: function() {
            this.$socket.disconnect();
        },
        connectSocket: function() {
            this.$socket.connect(); // if connection is not establised.
        },
        refine_pipe: function(cpu_pipe) {
          var jsonObj = JSON.parse(cpu_pipe)
          var cpuTotal = new Array;
          var jsonPercore = jsonObj.percore;
          var logCpu = "Emit Count <" + String(this.emitCount) + ">    :  ";
          for (let i = 0 ; i < jsonObj.nrCore ; i ++ ) {
            cpuTotal.push(jsonPercore[i].total);
            logCpu = logCpu + 'core[' + String(i+1) + '] : ' +  jsonPercore[i].total + '     / ';
          }
          this.appendLog(logCpu);
          return cpuTotal;
        }
    }
}
</script>
